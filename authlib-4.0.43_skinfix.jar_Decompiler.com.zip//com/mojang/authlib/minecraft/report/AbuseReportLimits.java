package com.mojang.authlib.minecraft.report;

public record AbuseReportLimits(int maxOpinionCommentsLength, int maxReportedMessageCount, int maxEvidenceMessageCount, int leadingContextMessageCount, int trailingContextMessageCount) {
   public static final AbuseReportLimits DEFAULTS = new AbuseReportLimits(1000, 4, 40, 9, 0);

   public AbuseReportLimits(int maxOpinionCommentsLength, int maxReportedMessageCount, int maxEvidenceMessageCount, int leadingContextMessageCount, int trailingContextMessageCount) {
      this.maxOpinionCommentsLength = maxOpinionCommentsLength;
      this.maxReportedMessageCount = maxReportedMessageCount;
      this.maxEvidenceMessageCount = maxEvidenceMessageCount;
      this.leadingContextMessageCount = leadingContextMessageCount;
      this.trailingContextMessageCount = trailingContextMessageCount;
   }

   public int maxOpinionCommentsLength() {
      return this.maxOpinionCommentsLength;
   }

   public int maxReportedMessageCount() {
      return this.maxReportedMessageCount;
   }

   public int maxEvidenceMessageCount() {
      return this.maxEvidenceMessageCount;
   }

   public int leadingContextMessageCount() {
      return this.leadingContextMessageCount;
   }

   public int trailingContextMessageCount() {
      return this.trailingContextMessageCount;
   }
}

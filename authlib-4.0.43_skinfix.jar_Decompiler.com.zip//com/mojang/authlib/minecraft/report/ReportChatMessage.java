package com.mojang.authlib.minecraft.report;

import java.nio.ByteBuffer;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

public class ReportChatMessage {
   public int index;
   public UUID profileId;
   public UUID sessionId;
   public Instant timestamp;
   public long salt;
   public List<ByteBuffer> lastSeen;
   public String message;
   public ByteBuffer signature;
   public boolean messageReported;

   public ReportChatMessage(int index, UUID profileId, UUID sessionId, Instant timestamp, long salt, List<ByteBuffer> lastSeen, String message, ByteBuffer signature, boolean messageReported) {
      this.index = index;
      this.profileId = profileId;
      this.sessionId = sessionId;
      this.timestamp = timestamp;
      this.salt = salt;
      this.lastSeen = lastSeen;
      this.message = message;
      this.signature = signature;
      this.messageReported = messageReported;
   }
}

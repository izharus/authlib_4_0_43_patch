package com.mojang.authlib.minecraft;

public interface TelemetrySession {
   TelemetrySession DISABLED = new TelemetrySession() {
      public boolean isEnabled() {
         return false;
      }

      public TelemetryEvent createNewEvent(String type) {
         return TelemetryEvent.EMPTY;
      }
   };

   boolean isEnabled();

   TelemetryEvent createNewEvent(String var1);
}

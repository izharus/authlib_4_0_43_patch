package com.mojang.authlib.minecraft;

import java.time.Instant;
import java.util.UUID;
import javax.annotation.Nullable;

public record BanDetails(UUID id, @Nullable Instant expires, @Nullable String reason, @Nullable String reasonMessage) {
   public static final String MULTIPLAYER_SCOPE = "MULTIPLAYER";

   public BanDetails(UUID id, @Nullable Instant expires, @Nullable String reason, @Nullable String reasonMessage) {
      this.id = id;
      this.expires = expires;
      this.reason = reason;
      this.reasonMessage = reasonMessage;
   }

   public UUID id() {
      return this.id;
   }

   @Nullable
   public Instant expires() {
      return this.expires;
   }

   @Nullable
   public String reason() {
      return this.reason;
   }

   @Nullable
   public String reasonMessage() {
      return this.reasonMessage;
   }
}

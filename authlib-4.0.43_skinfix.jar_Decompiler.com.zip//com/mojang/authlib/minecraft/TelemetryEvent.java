package com.mojang.authlib.minecraft;

public interface TelemetryEvent extends TelemetryPropertyContainer {
   TelemetryEvent EMPTY = new TelemetryEvent() {
      public void addProperty(String id, String value) {
      }

      public void addProperty(String id, int value) {
      }

      public void addProperty(String id, long value) {
      }

      public void addProperty(String id, boolean value) {
      }

      public void addNullProperty(String id) {
      }

      public void send() {
      }
   };

   void send();
}

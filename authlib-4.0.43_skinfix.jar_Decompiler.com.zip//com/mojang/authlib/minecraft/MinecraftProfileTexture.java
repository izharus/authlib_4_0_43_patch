package com.mojang.authlib.minecraft;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import javax.annotation.Nullable;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class MinecraftProfileTexture {
   public static final int PROFILE_TEXTURE_COUNT = MinecraftProfileTexture.Type.values().length;
   private final String url;
   private final Map<String, String> metadata;

   public MinecraftProfileTexture(String url, Map<String, String> metadata) {
      this.url = url;
      this.metadata = metadata;
   }

   public String getUrl() {
      return this.url;
   }

   @Nullable
   public String getMetadata(String key) {
      return this.metadata == null ? null : (String)this.metadata.get(key);
   }

   public String getHash() {
      try {
         return FilenameUtils.getBaseName((new URL(this.url)).getPath());
      } catch (MalformedURLException var2) {
         throw new IllegalArgumentException("Invalid profile texture url");
      }
   }

   public String toString() {
      return (new ToStringBuilder(this)).append("url", this.url).append("hash", this.getHash()).toString();
   }

   public static enum Type {
      SKIN,
      CAPE,
      ELYTRA;

      // $FF: synthetic method
      private static MinecraftProfileTexture.Type[] $values() {
         return new MinecraftProfileTexture.Type[]{SKIN, CAPE, ELYTRA};
      }
   }
}

package com.mojang.authlib.minecraft;

import com.mojang.authlib.minecraft.report.AbuseReportLimits;
import com.mojang.authlib.yggdrasil.request.AbuseReportRequest;
import com.mojang.authlib.yggdrasil.response.KeyPairResponse;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;
import javax.annotation.Nullable;

public interface UserApiService {
   UserApiService.UserProperties OFFLINE_PROPERTIES = new UserApiService.UserProperties(Set.of(UserApiService.UserFlag.CHAT_ALLOWED, UserApiService.UserFlag.REALMS_ALLOWED, UserApiService.UserFlag.SERVERS_ALLOWED), Map.of());
   UserApiService OFFLINE = new UserApiService() {
      public UserApiService.UserProperties properties() {
         return OFFLINE_PROPERTIES;
      }

      public boolean isBlockedPlayer(UUID playerID) {
         return false;
      }

      public void refreshBlockList() {
      }

      public TelemetrySession newTelemetrySession(Executor executor) {
         return TelemetrySession.DISABLED;
      }

      @Nullable
      public KeyPairResponse getKeyPair() {
         return null;
      }

      public void reportAbuse(AbuseReportRequest request) {
      }

      public boolean canSendReports() {
         return false;
      }

      public AbuseReportLimits getAbuseReportLimits() {
         return AbuseReportLimits.DEFAULTS;
      }
   };

   UserApiService.UserProperties properties();

   boolean isBlockedPlayer(UUID var1);

   void refreshBlockList();

   TelemetrySession newTelemetrySession(Executor var1);

   @Nullable
   KeyPairResponse getKeyPair();

   void reportAbuse(AbuseReportRequest var1);

   boolean canSendReports();

   AbuseReportLimits getAbuseReportLimits();

   public static record UserProperties(Set<UserApiService.UserFlag> flags, Map<String, BanDetails> bannedScopes) {
      public UserProperties(Set<UserApiService.UserFlag> flags, Map<String, BanDetails> bannedScopes) {
         this.flags = flags;
         this.bannedScopes = bannedScopes;
      }

      public boolean flag(UserApiService.UserFlag flag) {
         return this.flags.contains(flag);
      }

      public Set<UserApiService.UserFlag> flags() {
         return this.flags;
      }

      public Map<String, BanDetails> bannedScopes() {
         return this.bannedScopes;
      }
   }

   public static enum UserFlag {
      SERVERS_ALLOWED,
      REALMS_ALLOWED,
      CHAT_ALLOWED,
      TELEMETRY_ENABLED,
      PROFANITY_FILTER_ENABLED,
      OPTIONAL_TELEMETRY_AVAILABLE;

      // $FF: synthetic method
      private static UserApiService.UserFlag[] $values() {
         return new UserApiService.UserFlag[]{SERVERS_ALLOWED, REALMS_ALLOWED, CHAT_ALLOWED, TELEMETRY_ENABLED, PROFANITY_FILTER_ENABLED, OPTIONAL_TELEMETRY_AVAILABLE};
      }
   }
}

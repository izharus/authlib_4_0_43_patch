package com.mojang.authlib.yggdrasil;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.properties.Property;
import com.mojang.authlib.yggdrasil.response.Response;
import java.net.URL;
import java.nio.ByteBuffer;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import javax.annotation.Nullable;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class YggdrasilServicesKeyInfo implements ServicesKeyInfo {
   private static final Logger LOGGER = LoggerFactory.getLogger(YggdrasilServicesKeyInfo.class);
   private static final ScheduledExecutorService FETCHER_EXECUTOR = Executors.newScheduledThreadPool(1, (new ThreadFactoryBuilder()).setNameFormat("Yggdrasil Key Fetcher").setDaemon(true).build());
   private static final int KEY_SIZE_BITS = 4096;
   private static final String KEY_ALGORITHM = "RSA";
   private static final String SIGNATURE_ALGORITHM = "SHA1withRSA";
   private static final int REFRESH_INTERVAL_HOURS = 24;
   private final PublicKey publicKey;

   private YggdrasilServicesKeyInfo(PublicKey publicKey) {
      this.publicKey = publicKey;
      String algorithm = publicKey.getAlgorithm();
      if (!algorithm.equals("RSA")) {
         throw new IllegalArgumentException("Expected RSA key, got " + algorithm);
      }
   }

   public static ServicesKeyInfo parse(byte[] keyBytes) {
      try {
         X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
         KeyFactory keyFactory = KeyFactory.getInstance("RSA");
         PublicKey publicKey = keyFactory.generatePublic(spec);
         return new YggdrasilServicesKeyInfo(publicKey);
      } catch (InvalidKeySpecException | NoSuchAlgorithmException var4) {
         throw new IllegalArgumentException("Invalid yggdrasil public key!", var4);
      }
   }

   private static List<ServicesKeyInfo> parseList(@Nullable List<YggdrasilServicesKeyInfo.KeyData> keys) {
      return keys == null ? List.of() : keys.stream().map((data) -> {
         return parse(data.publicKey.array());
      }).toList();
   }

   public static ServicesKeySet get(URL url, YggdrasilAuthenticationService authenticationService) {
      CompletableFuture<?> ready = new CompletableFuture();
      AtomicReference<ServicesKeySet> keySet = new AtomicReference(ServicesKeySet.EMPTY);
      FETCHER_EXECUTOR.scheduleAtFixedRate(() -> {
         Optional var10000 = fetch(url, authenticationService);
         Objects.requireNonNull(keySet);
         var10000.ifPresent(keySet::set);
         ready.complete((Object)null);
      }, 0L, 24L, TimeUnit.HOURS);
      return ServicesKeySet.lazy(() -> {
         ready.join();
         return (ServicesKeySet)keySet.get();
      });
   }

   private static Optional<ServicesKeySet> fetch(URL url, YggdrasilAuthenticationService authenticationService) {
      YggdrasilServicesKeyInfo.KeySetResponse response;
      try {
         response = (YggdrasilServicesKeyInfo.KeySetResponse)authenticationService.makeRequest(url, (Object)null, YggdrasilServicesKeyInfo.KeySetResponse.class);
      } catch (AuthenticationException var6) {
         LOGGER.error("Failed to request yggdrasil public key", var6);
         return Optional.empty();
      }

      if (response == null) {
         return Optional.empty();
      } else if (StringUtils.isNotBlank(response.getError())) {
         LOGGER.error("Did not receive yggdrasil public key data, error: {} {}", response.getError(), response.getErrorMessage());
         return Optional.empty();
      } else {
         try {
            List<ServicesKeyInfo> profilePropertyKeys = parseList(response.profilePropertyKeys);
            List<ServicesKeyInfo> playerCertificateKeys = parseList(response.playerCertificateKeys);
            return Optional.of((type) -> {
               List var10000;
               switch(type) {
               case PROFILE_PROPERTY:
                  var10000 = profilePropertyKeys;
                  break;
               case PROFILE_KEY:
                  var10000 = playerCertificateKeys;
                  break;
               default:
                  throw new IncompatibleClassChangeError();
               }

               return var10000;
            });
         } catch (Exception var5) {
            LOGGER.error("Received malformed yggdrasil public key data", var5);
            return Optional.empty();
         }
      }
   }

   public Signature signature() {
      try {
         Signature signature = Signature.getInstance("SHA1withRSA");
         signature.initVerify(this.publicKey);
         return signature;
      } catch (InvalidKeyException | NoSuchAlgorithmException var2) {
         throw new AssertionError("Failed to create signature", var2);
      }
   }

   public int keyBitCount() {
      return 4096;
   }

   public boolean validateProperty(Property property) {
      Signature signature = this.signature();
      byte[] expected = Base64.getDecoder().decode(property.getSignature());

      try {
         signature.update(property.getValue().getBytes());
         return signature.verify(expected);
      } catch (SignatureException var5) {
         LOGGER.error("Failed to verify signature on property {}", property, var5);
         return false;
      }
   }

   private static class KeySetResponse extends Response {
      @Nullable
      public final List<YggdrasilServicesKeyInfo.KeyData> profilePropertyKeys;
      @Nullable
      public final List<YggdrasilServicesKeyInfo.KeyData> playerCertificateKeys;

      public KeySetResponse(@Nullable List<YggdrasilServicesKeyInfo.KeyData> profilePropertyKeys, @Nullable List<YggdrasilServicesKeyInfo.KeyData> playerCertificateKeys) {
         this.profilePropertyKeys = profilePropertyKeys;
         this.playerCertificateKeys = playerCertificateKeys;
      }
   }

   private static record KeyData(ByteBuffer publicKey) {
      private KeyData(ByteBuffer publicKey) {
         this.publicKey = publicKey;
      }

      public ByteBuffer publicKey() {
         return this.publicKey;
      }
   }
}

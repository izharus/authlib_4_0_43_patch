package com.mojang.authlib.yggdrasil;

public enum ServicesKeyType {
   PROFILE_PROPERTY,
   PROFILE_KEY;

   // $FF: synthetic method
   private static ServicesKeyType[] $values() {
      return new ServicesKeyType[]{PROFILE_PROPERTY, PROFILE_KEY};
   }
}

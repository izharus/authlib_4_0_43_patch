package com.mojang.authlib.yggdrasil;

import com.mojang.authlib.Agent;
import com.mojang.authlib.Environment;
import com.mojang.authlib.EnvironmentParser;
import com.mojang.authlib.GameProfileRepository;
import com.mojang.authlib.HttpAuthenticationService;
import com.mojang.authlib.UserAuthentication;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.exceptions.AuthenticationUnavailableException;
import com.mojang.authlib.exceptions.InsufficientPrivilegesException;
import com.mojang.authlib.exceptions.InvalidCredentialsException;
import com.mojang.authlib.exceptions.MinecraftClientException;
import com.mojang.authlib.exceptions.UserBannedException;
import com.mojang.authlib.exceptions.UserMigratedException;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import com.mojang.authlib.minecraft.UserApiService;
import com.mojang.authlib.minecraft.client.ObjectMapper;
import com.mojang.authlib.yggdrasil.response.Response;
import java.io.IOException;
import java.net.Proxy;
import java.net.URL;
import javax.annotation.Nullable;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class YggdrasilAuthenticationService extends HttpAuthenticationService {
   private static final Logger LOGGER = LoggerFactory.getLogger(YggdrasilAuthenticationService.class);
   @Nullable
   private final String clientToken;
   private final ObjectMapper objectMapper;
   private final Environment environment;
   private final ServicesKeySet servicesKeySet;

   public YggdrasilAuthenticationService(Proxy proxy) {
      this(proxy, determineEnvironment());
   }

   public YggdrasilAuthenticationService(Proxy proxy, Environment environment) {
      this(proxy, (String)null, environment);
   }

   public YggdrasilAuthenticationService(Proxy proxy, @Nullable String clientToken) {
      this(proxy, clientToken, determineEnvironment());
   }

   public YggdrasilAuthenticationService(Proxy proxy, @Nullable String clientToken, Environment environment) {
      super(proxy);
      this.objectMapper = ObjectMapper.create();
      this.clientToken = clientToken;
      this.environment = environment;
      LOGGER.info("Environment: " + environment.asString());
      URL publicKeySetUrl = HttpAuthenticationService.constantURL(environment.getServicesHost() + "/publickeys");
      this.servicesKeySet = YggdrasilServicesKeyInfo.get(publicKeySetUrl, this);
   }

   private static Environment determineEnvironment() {
      return (Environment)EnvironmentParser.getEnvironmentFromProperties().orElse(YggdrasilEnvironment.PROD.getEnvironment());
   }

   public UserAuthentication createUserAuthentication(Agent agent) {
      if (this.clientToken == null) {
         throw new IllegalStateException("Missing client token");
      } else {
         return new YggdrasilUserAuthentication(this, this.clientToken, agent, this.environment);
      }
   }

   public MinecraftSessionService createMinecraftSessionService() {
      return new YggdrasilMinecraftSessionService(this, this.environment);
   }

   public GameProfileRepository createProfileRepository() {
      return new YggdrasilGameProfileRepository(this, this.environment);
   }

   public ServicesKeySet getServicesKeySet() {
      return this.servicesKeySet;
   }

   protected <T extends Response> T makeRequest(URL url, Object input, Class<T> classOfT) throws AuthenticationException {
      return this.makeRequest(url, input, classOfT, (String)null);
   }

   protected <T extends Response> T makeRequest(URL url, Object input, Class<T> classOfT, @Nullable String authentication) throws AuthenticationException {
      try {
         String jsonResult = input == null ? this.performGetRequest(url, authentication) : this.performPostRequest(url, this.objectMapper.writeValueAsString(input), "application/json");
         T result = (Response)this.objectMapper.readValue(jsonResult, classOfT);
         if (result == null) {
            return null;
         } else if (StringUtils.isNotBlank(result.getError())) {
            if ("UserMigratedException".equals(result.getCause())) {
               throw new UserMigratedException(result.getErrorMessage());
            } else if ("ForbiddenOperationException".equals(result.getError())) {
               throw new InvalidCredentialsException(result.getErrorMessage());
            } else if ("InsufficientPrivilegesException".equals(result.getError())) {
               throw new InsufficientPrivilegesException(result.getErrorMessage());
            } else if ("multiplayer.access.banned".equals(result.getError())) {
               throw new UserBannedException();
            } else {
               throw new AuthenticationException(result.getErrorMessage());
            }
         } else {
            return result;
         }
      } catch (IllegalStateException | MinecraftClientException | IOException var7) {
         throw new AuthenticationUnavailableException("Cannot contact authentication server", var7);
      }
   }

   public UserApiService createUserApiService(String accessToken) throws AuthenticationException {
      return new YggdrasilUserApiService(accessToken, this.getProxy(), this.environment);
   }
}

package com.mojang.authlib.exceptions;

public class UserBannedException extends AuthenticationException {
}
